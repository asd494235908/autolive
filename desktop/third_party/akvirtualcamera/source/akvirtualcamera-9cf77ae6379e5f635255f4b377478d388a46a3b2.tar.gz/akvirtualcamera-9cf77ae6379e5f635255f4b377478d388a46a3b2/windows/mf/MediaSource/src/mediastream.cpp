/* akvirtualcamera, virtual camera for Mac and Windows.
 * Copyright (C) 2025  Gonzalo Exequiel Pedone
 *
 * akvirtualcamera is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * akvirtualcamera is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with akvirtualcamera. If not, see <http://www.gnu.org/licenses/>.
 *
 * Web-Site: http://webcamoid.github.io/
 */

#include <algorithm>
#include <atomic>
#include <vector>
#include <memory>
#include <mutex>
#include <random>
#include <windows.h>
#include <mfapi.h>
#include <mferror.h>
#include <mfidl.h>
#include <mfobjects.h>
#include <propvarutil.h>

#include "mediastream.h"
#include "mediasource.h"
#include "mfvcam.h"
#include "PlatformUtils/src/cunknown.h"
#include "PlatformUtils/src/utils.h"
#include "PlatformUtils/src/preferences.h"
#include "VCamUtils/src/fraction.h"
#include "VCamUtils/src/videoadjusts.h"
#include "VCamUtils/src/videoconverter.h"
#include "VCamUtils/src/videoformat.h"
#include "VCamUtils/src/videoframe.h"
#include "MFUtils/src/utils.h"

#define TIME_BASE 1.0e7

enum FrameSourceTypes
{
    FrameSourceTypes_Color = 0x1,
};

enum MediaStreamState
{
    MediaStreamState_Stopped,
    MediaStreamState_Started,
    MediaStreamState_Paused
};

namespace AkVCam
{
    class MediaStreamPrivate
    {
        public:
            MediaStream *self;
            std::atomic<uint64_t> m_refCount {1};
            IpcBridgePtr m_bridge;
            std::string m_deviceId;
            MediaSource *m_mediaSource {nullptr};
            IMFStreamDescriptor *m_streamDescriptor {nullptr};
            MediaStreamState m_state {MediaStreamState_Stopped};
            LONGLONG m_sampleCount {0};
            std::vector<std::shared_ptr<IUnknown>> m_sampleTokens;
            VideoFormat m_format;
            IMFMediaType *m_mediaType {nullptr};
            std::atomic<bool> m_running {false};
            std::mutex m_mutex;
            VideoFrame m_currentFrame;
            VideoFrame m_testFrame;
            VideoAdjusts m_videoAdjusts;
            VideoConverter m_videoConverter;
            LONGLONG m_pts {-1};
            LONGLONG m_ptsDrift {0};
            bool m_horizontalFlip {false};   // Controlled by client
            bool m_verticalFlip {false};
            LONG m_brightness {0};
            LONG m_contrast {0};
            LONG m_saturation {0};
            LONG m_gamma {0};
            LONG m_hue {0};
            LONG m_colorEnable {1};
            bool m_isRgb {false};
            bool m_frameReady {false};
            bool m_directMode {false};

            explicit MediaStreamPrivate(MediaStream *self);
            HRESULT queueSample();
            VideoFrame applyAdjusts(const VideoFrame &frame);
            static void propertyChanged(void *userData,
                                        LONG property,
                                        LONG value,
                                        LONG flags);
            VideoFrame randomFrame();
    };
}

AkVCam::MediaStream::MediaStream(MediaSource *mediaSource,
                                 IMFStreamDescriptor *streamDescriptor)
{
    this->d = new MediaStreamPrivate(this);

    this->d->m_mediaSource = mediaSource;
    this->d->m_streamDescriptor = streamDescriptor;
    this->d->m_streamDescriptor->AddRef();
    this->d->m_deviceId = this->d->m_mediaSource->deviceId();
    this->d->m_directMode = this->d->m_mediaSource->directMode();

    this->SetGUID(AKVCAM_MF_DEVICESTREAM_STREAM_CATEGORY, AKVCAM_PINNAME_VIDEO_CAPTURE);
    this->SetUINT32(AKVCAM_MF_DEVICESTREAM_STREAM_ID, 0);
    this->SetUINT32(AKVCAM_MF_DEVICESTREAM_FRAMESERVER_SHARED, 1);
    this->SetUINT32(AKVCAM_MF_DEVICESTREAM_ATTRIBUTE_FRAMESOURCE_TYPES,
                    FrameSourceTypes_Color);

    auto cameraIndex = Preferences::cameraFromId(this->d->m_deviceId);

    auto horizontalMirror = Preferences::cameraControlValue(cameraIndex, "hflip") > 0;
    auto verticalMirror = Preferences::cameraControlValue(cameraIndex, "vflip") > 0;
    auto scaling = VideoConverter::ScalingMode(Preferences::cameraControlValue(cameraIndex, "scaling"));
    auto aspectRatio = VideoConverter::AspectRatioMode(Preferences::cameraControlValue(cameraIndex, "aspect_ratio"));
    auto swapRgb = Preferences::cameraControlValue(cameraIndex, "swap_rgb") > 0;

    this->d->m_videoAdjusts.setHue(this->d->m_hue);
    this->d->m_videoAdjusts.setSaturation(this->d->m_saturation);
    this->d->m_videoAdjusts.setLuminance(this->d->m_brightness);
    this->d->m_videoAdjusts.setGamma(this->d->m_gamma);
    this->d->m_videoAdjusts.setContrast(this->d->m_contrast);
    this->d->m_videoAdjusts.setGrayScaled(!this->d->m_colorEnable);
    this->d->m_videoAdjusts.setHorizontalMirror(horizontalMirror);
    this->d->m_videoAdjusts.setVerticalMirror(verticalMirror);
    this->d->m_videoAdjusts.setSwapRGB(swapRgb);
    this->d->m_videoConverter.setAspectRatioMode(VideoConverter::AspectRatioMode(aspectRatio));
    this->d->m_videoConverter.setScalingMode(VideoConverter::ScalingMode(scaling));

    auto picture = Preferences::picture();

    if (!picture.empty()) {
        this->d->m_mutex.lock();
        this->d->m_testFrame = loadPicture(picture);
        this->d->m_mutex.unlock();
    }

    LONG flags = 0;
    this->d->m_mediaSource->Get(VideoProcAmp_Brightness,
                               &this->d->m_brightness,
                               &flags);
    this->d->m_mediaSource->Get(VideoProcAmp_Contrast,
                               &this->d->m_contrast,
                               &flags);
    this->d->m_mediaSource->Get(VideoProcAmp_Saturation,
                               &this->d->m_saturation,
                               &flags);
    this->d->m_mediaSource->Get(VideoProcAmp_Gamma,
                               &this->d->m_gamma,
                               &flags);
    this->d->m_mediaSource->Get(VideoProcAmp_Hue,
                               &this->d->m_hue,
                               &flags);
    this->d->m_mediaSource->Get(VideoProcAmp_ColorEnable,
                               &this->d->m_colorEnable,
                               &flags);

    this->d->m_mediaSource->connectPropertyChanged(this->d,
                                                   &MediaStreamPrivate::propertyChanged);
}

AkVCam::MediaStream::~MediaStream()
{
    if (this->d->m_streamDescriptor)
        this->d->m_streamDescriptor->Release();

    if (this->d->m_mediaType)
        this->d->m_mediaType->Release();

    delete this->d;
}

void AkVCam::MediaStream::setBridge(IpcBridgePtr bridge)
{
    this->d->m_bridge = bridge;
}

void AkVCam::MediaStream::frameReady(const VideoFrame &frame, bool isActive)
{
    AkLogFunction();
    AkLogDebug("Running: %d", static_cast<bool>(this->d->m_running));

    if (!this->d->m_running)
        return;

    AkLogDebug("Active: %d", isActive);

    if (this->d->m_directMode) {
        std::unique_lock<std::mutex> lock(this->d->m_mutex);

        if (isActive && frame && this->d->m_format.isSameFormat(frame.format())) {
            memcpy(this->d->m_currentFrame.data(),
                   frame.constData(),
                   frame.size());
            this->d->m_frameReady = true;
        } else if (!isActive && this->d->m_testFrame) {
            VideoFrame inputFrame = this->d->m_testFrame;

            lock.unlock();
            auto adjusted = this->d->applyAdjusts(inputFrame);
            lock.lock();

            this->d->m_currentFrame = adjusted;
            this->d->m_frameReady = true;
        } else {
            this->d->m_frameReady = false;
        }
    } else {
        VideoFrame inputFrame;

        {
            std::lock_guard<std::mutex> lock(this->d->m_mutex);
            inputFrame = isActive? frame: this->d->m_testFrame;
        }

        auto frameAdjusted = this->d->applyAdjusts(inputFrame);

        {
            std::lock_guard<std::mutex> lock(this->d->m_mutex);

            if (frameAdjusted) {
                this->d->m_currentFrame = frameAdjusted;
                this->d->m_frameReady = true;
            } else {
                this->d->m_frameReady = false;
            }
        }
    }
}

void AkVCam::MediaStream::setPicture(const std::string &picture)
{
    AkLogFunction();
    AkLogDebug("Picture: %s", picture.c_str());
    this->d->m_mutex.lock();
    this->d->m_testFrame = loadPicture(picture);
    this->d->m_mutex.unlock();
}

void AkVCam::MediaStream::setControls(const std::map<std::string, int> &controls)
{
    AkLogFunction();

    if (this->d->m_directMode)
        return;

    for (auto &control: controls) {
        AkLogDebug("%s: %d", control.first.c_str(), control.second);

        if (control.first == "hflip")
            this->d->m_videoAdjusts.setHorizontalMirror(control.second > 0);
        else if (control.first == "vflip")
            this->d->m_videoAdjusts.setVerticalMirror(control.second > 0);
        else if (control.first == "swap_rgb")
            this->d->m_videoAdjusts.setSwapRGB(control.second > 0);
        else if (control.first == "aspect_ratio")
            this->d->m_videoConverter.setAspectRatioMode(VideoConverter::AspectRatioMode(control.second));
        else if (control.first == "scaling")
            this->d->m_videoConverter.setScalingMode(VideoConverter::ScalingMode(control.second));
    }
}

bool AkVCam::MediaStream::horizontalFlip() const
{
    return this->d->m_horizontalFlip;
}

void AkVCam::MediaStream::setHorizontalFlip(bool flip)
{
    this->d->m_horizontalFlip = flip;
    this->d->m_videoAdjusts.setHorizontalMirror(flip);
}

bool AkVCam::MediaStream::verticalFlip() const
{
    return this->d->m_verticalFlip;
}

void AkVCam::MediaStream::setVerticalFlip(bool flip)
{
    this->d->m_verticalFlip = flip;
    this->d->m_videoAdjusts.setVerticalMirror(flip);
}

HRESULT AkVCam::MediaStream::start(IMFMediaType *mediaType)
{
    AkLogFunction();
    std::lock_guard<std::mutex> lock(this->d->m_mutex);

    if (this->d->m_state != MediaStreamState_Stopped)
        return MF_E_INVALID_STATE_TRANSITION;

    this->d->m_pts = -1;
    this->d->m_ptsDrift = 0;
    this->d->m_format = formatFromMFMediaType(mediaType);
    this->d->m_state = MediaStreamState_Started;
    this->d->m_running = true;
    this->d->m_frameReady = false;
    this->d->m_currentFrame = {this->d->m_format};
    this->d->m_sampleCount = 0;
    this->d->m_sampleTokens.clear();
    this->d->m_videoConverter.setOutputFormat(this->d->m_format);

    if (this->d->m_mediaType)
        this->d->m_mediaType->Release();

    this->d->m_mediaType = mediaType;
    this->d->m_mediaType->AddRef();

    auto specs = VideoFormat::formatSpecs(this->d->m_format.format());
    this->d->m_isRgb = specs.type() == VideoFormatSpec::VFT_RGB;

    if (this->d->m_bridge)
        this->d->m_bridge->deviceStart(IpcBridge::StreamType_Input,
                                       this->d->m_deviceId);

    return S_OK;
}

HRESULT AkVCam::MediaStream::stop()
{
    AkLogFunction();

    {
        std::lock_guard<std::mutex> lock(this->d->m_mutex);

        if (this->d->m_state != MediaStreamState_Started
            && this->d->m_state != MediaStreamState_Paused) {
            return MF_E_INVALID_STATE_TRANSITION;
        }

        this->d->m_state = MediaStreamState_Stopped;
        this->d->m_running = false;

        if (this->d->m_bridge)
            this->d->m_bridge->deviceStop(this->d->m_deviceId);

        this->d->m_currentFrame = {};

        if (this->d->m_mediaType) {
            this->d->m_mediaType->Release();
            this->d->m_mediaType = nullptr;
        }
    }

    return this->eventQueue()->QueueEventParamVar(MEStreamStopped,
                                                  GUID_NULL,
                                                  S_OK,
                                                  nullptr);
}

HRESULT AkVCam::MediaStream::pause()
{
    AkLogFunction();
    std::lock_guard<std::mutex> lock(this->d->m_mutex);

    if (this->d->m_state != MediaStreamState_Started)
        return MF_E_INVALID_STATE_TRANSITION;

    this->d->m_state = MediaStreamState_Paused;
    this->d->m_running = true;

    return this->eventQueue()->QueueEventParamVar(MEStreamPaused,
                                                  GUID_NULL,
                                                  S_OK,
                                                  nullptr);
}

HRESULT AkVCam::MediaStream::resume()
{
    AkLogFunction();
    std::lock_guard<std::mutex> lock(this->d->m_mutex);

    if (this->d->m_state != MediaStreamState_Paused)
        return MF_E_INVALID_STATE_TRANSITION;

    this->d->m_state = MediaStreamState_Started;

    PROPVARIANT time;
    InitPropVariantFromInt64(MFGetSystemTime(), &time);

    return this->eventQueue()->QueueEventParamVar(MEStreamStarted,
                                                  GUID_NULL,
                                                  S_OK,
                                                  &time);
}

HRESULT AkVCam::MediaStream::QueryInterface(const IID &riid, void **ppv)
{
    AkLogFunction();
    AkLogDebug("IID: %s", stringFromClsidMF(riid).c_str());

    if (!ppv)
        return E_POINTER;

    const struct
    {
        const IID *iid;
        void *ptr;
    } comInterfaceEntryMediaSample[] = {
        COM_INTERFACE(IMFMediaEventGenerator)
        COM_INTERFACE(IMFMediaStream)
        COM_INTERFACE(IMFAttributes)
        COM_INTERFACE2(IUnknown, IMFMediaStream)
        COM_INTERFACE_NULL
    };

    for (auto map = comInterfaceEntryMediaSample; map->ptr; ++map)
        if (*map->iid == riid) {
            *ppv = map->ptr;
            this->AddRef();

            return S_OK;
        }

    *ppv = nullptr;
    AkLogDebug("Interface not found");

    return E_NOINTERFACE;
}

ULONG AkVCam::MediaStream::AddRef()
{
    AkLogFunction();

    return ++this->d->m_refCount;
}

ULONG AkVCam::MediaStream::Release()
{
    AkLogFunction();
    ULONG ref = --this->d->m_refCount;

    if (ref == 0)
        delete this;

    return ref;
}

HRESULT AkVCam::MediaStream::GetMediaSource(IMFMediaSource **ppMediaSource)
{
    AkLogFunction();

    if (!ppMediaSource)
        return E_POINTER;

    std::lock_guard<std::mutex> lock(this->d->m_mutex);

    if (!this->d->m_mediaSource)
        return E_UNEXPECTED;

    *ppMediaSource = this->d->m_mediaSource;
    (*ppMediaSource)->AddRef();

    return S_OK;
}

HRESULT AkVCam::MediaStream::GetStreamDescriptor(IMFStreamDescriptor **ppStreamDescriptor)
{
    AkLogFunction();

    if (!ppStreamDescriptor)
        return E_POINTER;

    std::lock_guard<std::mutex> lock(this->d->m_mutex);

    if (!this->d->m_streamDescriptor)
        return E_UNEXPECTED;

    *ppStreamDescriptor = this->d->m_streamDescriptor;
    (*ppStreamDescriptor)->AddRef();

    return S_OK;
}

HRESULT AkVCam::MediaStream::RequestSample(IUnknown *pToken)
{
    AkLogFunction();

    AkLogDebug("Saving token");

    // Save the token if available
    if (pToken) {
        std::lock_guard<std::mutex> lock(this->d->m_mutex);

        std::shared_ptr<IUnknown> token(pToken, [] (IUnknown *pToken) {
            pToken->Release();
        });
        pToken->AddRef();

        this->d->m_sampleTokens.push_back(token);
    }

    auto hr = this->d->queueSample();

    if (FAILED(hr))
        AkLogError("Failed to queue sample: 0x%x", hr);

    return hr;
}

AkVCam::MediaStreamPrivate::MediaStreamPrivate(MediaStream *self):
    self(self)
{

}

HRESULT AkVCam::MediaStreamPrivate::queueSample()
{
    AkLogFunction();

    IMFSample *pSample = nullptr;
    auto hr = MFCreateSample(&pSample);

    if (FAILED(hr)) {
        AkLogError("Failed creating sample: 0x%x", hr);

        return hr;
    }

    LONG dstStride = 0;

    if (FAILED(this->m_mediaType->GetUINT32(MF_MT_DEFAULT_STRIDE,
                                            reinterpret_cast<UINT32*>(&dstStride)))
        || dstStride == 0) {
        auto fourcc = fourccFromPixelFormat(this->m_format.format());
        MFGetStrideForBitmapInfoHeader(fourcc,
                                       this->m_format.width(),
                                       &dstStride);
    }

    DWORD absDstStride = static_cast<DWORD>(std::abs(dstStride));
    UINT32 sampleSize = 0;
    this->m_mediaType->GetUINT32(MF_MT_SAMPLE_SIZE, &sampleSize);

    if (sampleSize == 0) {
        UINT32 width = this->m_format.width();
        UINT32 height = this->m_format.height();
        auto mediaFormat = mediaFormatFromPixelFormat(this->m_format.format());
        MFCalculateImageSize(mediaFormat, width, height, &sampleSize);
    }

    if (sampleSize == 0) {
        AkLogError("Cannot determine sample size");
        pSample->Release();

        return MF_E_INVALIDMEDIATYPE;
    }

    IMFMediaBuffer *pBuffer = nullptr;
    hr = MFCreateMemoryBuffer(sampleSize, &pBuffer);

    if (FAILED(hr)) {
        AkLogError("Failed create the buffer: 0x%x", hr);
        pSample->Release();

        return hr;
    }

    hr = pSample->AddBuffer(pBuffer);

    if (FAILED(hr)) {
        AkLogError("Failed adding the buffer to the sample: 0x%x", hr);
        pBuffer->Release();
        pSample->Release();

        return hr;
    }

    BYTE *pData = nullptr;
    DWORD maxLen = 0;
    DWORD curLen = 0;
    hr = pBuffer->Lock(&pData, &maxLen, &curLen);

    if (FAILED(hr)) {
        AkLogError("Failed to lock the buffer: 0x%x", hr);
        pBuffer->Release();
        pSample->Release();

        return hr;
    }

    {
        std::lock_guard<std::mutex> lock(this->m_mutex);

        if (this->m_frameReady && this->m_currentFrame.size() > 0) {
            DWORD height = this->m_format.height();

            if (this->m_isRgb) {
                auto lineSize =
                        std::min<size_t>(absDstStride,
                                         this->m_currentFrame.lineSize(0));
                auto dstLine = pData;

                for (DWORD y = 0; y < height; ++y) {
                    auto srcLine = this->m_currentFrame.constLine(0, height - y - 1);
                    memcpy(dstLine, srcLine, lineSize);
                    dstLine += absDstStride;
                }
            } else {
                auto dstLine = pData;

                for (int plane = 0; plane < this->m_currentFrame.planes(); ++plane) {
                    auto lineSize =
                            std::min<size_t>(absDstStride,
                                             this->m_currentFrame.lineSize(plane));

                    for (DWORD y = 0; y < height; ++y) {
                        auto srcLine = this->m_currentFrame.constLine(plane, y);
                        memcpy(dstLine, srcLine, lineSize);
                        dstLine += absDstStride;
                    }
                }
            }
        } else {
            auto frame = this->randomFrame();
            size_t copyBytes = std::min<size_t>(maxLen, frame.size());

            if (copyBytes > 0)
                memcpy(pData, frame.constData(), copyBytes);
        }
    }

    pBuffer->Unlock();
    hr = pBuffer->SetCurrentLength(sampleSize);

    if (FAILED(hr)) {
        AkLogError("Failed setting the current buffer length: 0x%x", hr);
        pBuffer->Release();
        pSample->Release();

        return hr;
    }

    auto clock = LONGLONG(TIME_BASE * timeGetTime() / 1e3);
    auto fps = this->m_format.fps();
    auto duration = fps.value() > 0.0?
                        LONGLONG(TIME_BASE / fps.value()):
                        LONGLONG(TIME_BASE / 30.0);

    if (this->m_pts < 0) {
        this->m_pts = 0;
        this->m_ptsDrift = this->m_pts - clock;
    } else {
        auto diff = clock - this->m_pts + this->m_ptsDrift;

        if (diff <= 2 * duration) {
            this->m_pts = clock + this->m_ptsDrift;
        } else {
            this->m_pts += duration;
            this->m_ptsDrift = this->m_pts - clock;
        }
    }

    hr = pSample->SetSampleTime(this->m_pts);

    if (FAILED(hr)) {
        AkLogError("Failed setting the sample time: 0x%x", hr);
        pBuffer->Release();
        pSample->Release();

        return hr;
    }

    hr = pSample->SetSampleDuration(duration);

    if (FAILED(hr)) {
        AkLogError("Failed setting the sample duration: 0x%x", hr);
        pBuffer->Release();
        pSample->Release();

        return hr;
    }

    // if there are any token available take the first
    {
        std::lock_guard<std::mutex> lock(this->m_mutex);

        if (!this->m_sampleTokens.empty()) {
            auto token = this->m_sampleTokens.front();
            this->m_sampleTokens.erase(this->m_sampleTokens.begin());

            hr = pSample->SetUnknown(MFSampleExtension_Token, token.get());

            if (FAILED(hr)) {
                AkLogError("Failed setting the sample token: 0x%x", hr);
                pBuffer->Release();
                pSample->Release();

                return hr;
            }
        }
    }

    // Enqueue the sample event
    hr = self->eventQueue()->QueueEventParamUnk(MEMediaSample,
                                                GUID_NULL,
                                                S_OK,
                                                pSample);

    if (SUCCEEDED(hr))
        AkLogDebug("Sample queued");
    else
        AkLogError("Sample event queue failed: 0x%x", hr);

    pSample->Release();
    pBuffer->Release();

    return hr;
}

void AkVCam::MediaStreamPrivate::propertyChanged(void *userData,
                                                 LONG property,
                                                 LONG value,
                                                 LONG flags)
{
    AkLogFunction();
    UNUSED(flags);
    auto self = reinterpret_cast<MediaStreamPrivate *>(userData);

    switch (property) {
    case VideoProcAmp_Brightness:
        self->m_brightness = value;
        self->m_videoAdjusts.setLuminance(self->m_brightness);

        break;

    case VideoProcAmp_Contrast:
        self->m_contrast = value;
        self->m_videoAdjusts.setContrast(self->m_contrast);

        break;

    case VideoProcAmp_Saturation:
        self->m_saturation = value;
        self->m_videoAdjusts.setSaturation(self->m_saturation);

        break;

    case VideoProcAmp_Gamma:
        self->m_gamma = value;
        self->m_videoAdjusts.setGamma(self->m_gamma);

        break;

    case VideoProcAmp_Hue:
        self->m_hue = value;
        self->m_videoAdjusts.setHue(self->m_hue);

        break;

    case VideoProcAmp_ColorEnable:
        self->m_colorEnable = value;
        self->m_videoAdjusts.setGrayScaled(!self->m_colorEnable);

        break;

    default:
        break;
    }
}

AkVCam::VideoFrame AkVCam::MediaStreamPrivate::applyAdjusts(const VideoFrame &frame)
{
    AkLogFunction();

    if (!this->m_format)
        return {};

    VideoFrame newFrame;

    this->m_videoConverter.begin();

    if (this->m_directMode) {
        newFrame = this->m_videoConverter.convert(frame);
    } else {
        int width = this->m_format.width();
        int height = this->m_format.height();

        if (width * height > frame.format().width() * frame.format().height()) {
            newFrame = this->m_videoAdjusts.adjust(frame);
            newFrame = this->m_videoConverter.convert(newFrame);
        } else {
            newFrame = this->m_videoConverter.convert(frame);
            newFrame = this->m_videoAdjusts.adjust(newFrame);
        }
    }

    this->m_videoConverter.end();

    return newFrame;
}

AkVCam::VideoFrame AkVCam::MediaStreamPrivate::randomFrame()
{
    if (!this->m_format)
        return {};

    VideoFrame frame(this->m_format);
    thread_local std::default_random_engine engine(std::random_device{}());
    thread_local std::uniform_int_distribution<int> distribution(0, 255);
    std::generate(frame.data(),
                  frame.data() + frame.size(),
                  [] () {
        return uint8_t(distribution(engine));
    });

    return this->m_videoAdjusts.adjust(frame);
}
